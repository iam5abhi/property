"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/property/update-property";
exports.ids = ["pages/api/property/update-property"];
exports.modules = {

/***/ "@xata.io/client":
/*!**********************************!*\
  !*** external "@xata.io/client" ***!
  \**********************************/
/***/ ((module) => {

module.exports = import("@xata.io/client");;

/***/ }),

/***/ "(api)/./pages/api/property/update-property.js":
/*!***********************************************!*\
  !*** ./pages/api/property/update-property.js ***!
  \***********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _src_xata__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../src/xata */ \"(api)/./src/xata.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_xata__WEBPACK_IMPORTED_MODULE_0__]);\n_src_xata__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n// Next.js API route support: https://nextjs.org/docs/api-routes/introduction\n\nconst xata = (0,_src_xata__WEBPACK_IMPORTED_MODULE_0__.getXataClient)();\nconst handler = async (req, res)=>{\n    const { id, title, phoneNumber, ask_price, type, link, requirement } = req.body;\n    const results = await xata.db.property.createOrUpdate(id, {\n        title,\n        phoneNumber,\n        ask_price,\n        type,\n        link,\n        requirement\n    });\n    res.send(results);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvcHJvcGVydHkvdXBkYXRlLXByb3BlcnR5LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsNkVBQTZFO0FBRTNCO0FBQ2xELE1BQU1DLE9BQU9ELHdEQUFhQTtBQUUxQixNQUFNRSxVQUFVLE9BQU9DLEtBQUtDO0lBRTFCLE1BQU0sRUFBRUMsRUFBRSxFQUFFQyxLQUFLLEVBQUVDLFdBQVcsRUFBRUMsU0FBUyxFQUFFQyxJQUFJLEVBQUVDLElBQUksRUFBRUMsV0FBVyxFQUFFLEdBQUdSLElBQUlTLElBQUk7SUFDL0UsTUFBTUMsVUFBVSxNQUFNWixLQUFLYSxFQUFFLENBQUNDLFFBQVEsQ0FBQ0MsY0FBYyxDQUFDWCxJQUFHO1FBQ3ZEQztRQUNBQztRQUNBQztRQUNBQztRQUNBQztRQUNBQztJQUNGO0lBQ0FQLElBQUlhLElBQUksQ0FBQ0o7QUFDWDtBQUVBLGlFQUFlWCxPQUFPQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJvbnRlbmQvLi9wYWdlcy9hcGkvcHJvcGVydHkvdXBkYXRlLXByb3BlcnR5LmpzPzA3NDIiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTmV4dC5qcyBBUEkgcm91dGUgc3VwcG9ydDogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvYXBpLXJvdXRlcy9pbnRyb2R1Y3Rpb25cblxuaW1wb3J0IHsgZ2V0WGF0YUNsaWVudCB9IGZyb20gXCIuLi8uLi8uLi9zcmMveGF0YVwiO1xuY29uc3QgeGF0YSA9IGdldFhhdGFDbGllbnQoKTtcblxuY29uc3QgaGFuZGxlciA9IGFzeW5jIChyZXEsIHJlcykgPT4ge1xuXG4gIGNvbnN0IHsgaWQsIHRpdGxlLCBwaG9uZU51bWJlciwgYXNrX3ByaWNlLCB0eXBlLCBsaW5rICxyZXF1aXJlbWVudCB9ID0gcmVxLmJvZHk7XG4gIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB4YXRhLmRiLnByb3BlcnR5LmNyZWF0ZU9yVXBkYXRlKGlkLHtcbiAgICB0aXRsZSwgXG4gICAgcGhvbmVOdW1iZXIsIFxuICAgIGFza19wcmljZSwgXG4gICAgdHlwZSwgXG4gICAgbGluayxcbiAgICByZXF1aXJlbWVudCxcbiAgfSk7XG4gIHJlcy5zZW5kKHJlc3VsdHMpO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgaGFuZGxlcjtcbiJdLCJuYW1lcyI6WyJnZXRYYXRhQ2xpZW50IiwieGF0YSIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJpZCIsInRpdGxlIiwicGhvbmVOdW1iZXIiLCJhc2tfcHJpY2UiLCJ0eXBlIiwibGluayIsInJlcXVpcmVtZW50IiwiYm9keSIsInJlc3VsdHMiLCJkYiIsInByb3BlcnR5IiwiY3JlYXRlT3JVcGRhdGUiLCJzZW5kIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/property/update-property.js\n");

/***/ }),

/***/ "(api)/./src/xata.js":
/*!*********************!*\
  !*** ./src/xata.js ***!
  \*********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   XataClient: () => (/* binding */ XataClient),\n/* harmony export */   getXataClient: () => (/* binding */ getXataClient)\n/* harmony export */ });\n/* harmony import */ var _xata_io_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @xata.io/client */ \"@xata.io/client\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_xata_io_client__WEBPACK_IMPORTED_MODULE_0__]);\n_xata_io_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n// Generated by Xata Codegen 0.18.0. Please do not edit.\n\n/** @typedef { import('./types').SchemaTables } SchemaTables */ /** @type { SchemaTables } */ const tables = [\n    {\n        name: \"contacts\",\n        columns: [\n            {\n                name: \"firstName\",\n                type: \"string\"\n            },\n            {\n                name: \"lastName\",\n                type: \"string\"\n            },\n            {\n                name: \"phoneNumber\",\n                type: \"string\"\n            },\n            {\n                name: \"location\",\n                type: \"string\"\n            },\n            {\n                name: \"email\",\n                type: \"string\"\n            },\n            {\n                name: \"imageUrl\",\n                type: \"string\"\n            }\n        ]\n    }\n];\n/** @type { import('@xata.io/client').ClientConstructor<{}> } */ const DatabaseClient = (0,_xata_io_client__WEBPACK_IMPORTED_MODULE_0__.buildClient)();\nconst defaultOptions = {\n    databaseURL: \"https://sandeep-kumar-s-workspace-b4csci.us-east-1.xata.sh/db/telephone-directory\",\n    apiKey: \"xau_THFyITTTEDuI5yK8d0dAu1C5x1Aue3Oh1\"\n};\n/** @typedef { import('./types').DatabaseSchema } DatabaseSchema */ /** @extends DatabaseClient<DatabaseSchema> */ class XataClient extends DatabaseClient {\n    constructor(options){\n        super({\n            ...defaultOptions,\n            ...options\n        }, tables);\n    }\n}\nlet instance = undefined;\n/** @type { () => XataClient } */ const getXataClient = ()=>{\n    if (instance) return instance;\n    instance = new XataClient();\n    return instance;\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMveGF0YS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSx3REFBd0Q7QUFDVjtBQUM5Qyw2REFBNkQsR0FDN0QsMkJBQTJCLEdBQzNCLE1BQU1DLFNBQVM7SUFDYjtRQUNFQyxNQUFNO1FBQ05DLFNBQVM7WUFDUDtnQkFBRUQsTUFBTTtnQkFBYUUsTUFBTTtZQUFTO1lBQ3BDO2dCQUFFRixNQUFNO2dCQUFZRSxNQUFNO1lBQVM7WUFDbkM7Z0JBQUVGLE1BQU07Z0JBQWVFLE1BQU07WUFBUztZQUN0QztnQkFBRUYsTUFBTTtnQkFBWUUsTUFBTTtZQUFTO1lBQ25DO2dCQUFFRixNQUFNO2dCQUFTRSxNQUFNO1lBQVM7WUFDaEM7Z0JBQUVGLE1BQU07Z0JBQVlFLE1BQU07WUFBUztTQUNwQztJQUNIO0NBQ0Q7QUFFRCw4REFBOEQsR0FDOUQsTUFBTUMsaUJBQWlCTCw0REFBV0E7QUFDbEMsTUFBTU0saUJBQWlCO0lBQ3JCQyxhQUFZO0lBQ1pDLFFBQVE7QUFDVjtBQUNBLGlFQUFpRSxHQUNqRSw0Q0FBNEMsR0FDckMsTUFBTUMsbUJBQW1CSjtJQUM5QkssWUFBWUMsT0FBTyxDQUFFO1FBQ25CLEtBQUssQ0FBQztZQUFFLEdBQUdMLGNBQWM7WUFBRSxHQUFHSyxPQUFPO1FBQUMsR0FBR1Y7SUFDM0M7QUFDRjtBQUNBLElBQUlXLFdBQVdDO0FBQ2YsK0JBQStCLEdBQ3hCLE1BQU1DLGdCQUFnQjtJQUMzQixJQUFJRixVQUFVLE9BQU9BO0lBQ3JCQSxXQUFXLElBQUlIO0lBQ2YsT0FBT0c7QUFDVCxFQUFFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJvbnRlbmQvLi9zcmMveGF0YS5qcz8yN2MzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEdlbmVyYXRlZCBieSBYYXRhIENvZGVnZW4gMC4xOC4wLiBQbGVhc2UgZG8gbm90IGVkaXQuXG5pbXBvcnQgeyBidWlsZENsaWVudCB9IGZyb20gXCJAeGF0YS5pby9jbGllbnRcIjtcbi8qKiBAdHlwZWRlZiB7IGltcG9ydCgnLi90eXBlcycpLlNjaGVtYVRhYmxlcyB9IFNjaGVtYVRhYmxlcyAqL1xuLyoqIEB0eXBlIHsgU2NoZW1hVGFibGVzIH0gKi9cbmNvbnN0IHRhYmxlcyA9IFtcbiAge1xuICAgIG5hbWU6IFwiY29udGFjdHNcIixcbiAgICBjb2x1bW5zOiBbXG4gICAgICB7IG5hbWU6IFwiZmlyc3ROYW1lXCIsIHR5cGU6IFwic3RyaW5nXCIgfSxcbiAgICAgIHsgbmFtZTogXCJsYXN0TmFtZVwiLCB0eXBlOiBcInN0cmluZ1wiIH0sXG4gICAgICB7IG5hbWU6IFwicGhvbmVOdW1iZXJcIiwgdHlwZTogXCJzdHJpbmdcIiB9LFxuICAgICAgeyBuYW1lOiBcImxvY2F0aW9uXCIsIHR5cGU6IFwic3RyaW5nXCIgfSxcbiAgICAgIHsgbmFtZTogXCJlbWFpbFwiLCB0eXBlOiBcInN0cmluZ1wiIH0sXG4gICAgICB7IG5hbWU6IFwiaW1hZ2VVcmxcIiwgdHlwZTogXCJzdHJpbmdcIiB9LFxuICAgIF0sXG4gIH0sXG5dO1xuXG4vKiogQHR5cGUgeyBpbXBvcnQoJ0B4YXRhLmlvL2NsaWVudCcpLkNsaWVudENvbnN0cnVjdG9yPHt9PiB9ICovXG5jb25zdCBEYXRhYmFzZUNsaWVudCA9IGJ1aWxkQ2xpZW50KCk7XG5jb25zdCBkZWZhdWx0T3B0aW9ucyA9IHtcbiAgZGF0YWJhc2VVUkw6XCJodHRwczovL3NhbmRlZXAta3VtYXItcy13b3Jrc3BhY2UtYjRjc2NpLnVzLWVhc3QtMS54YXRhLnNoL2RiL3RlbGVwaG9uZS1kaXJlY3RvcnlcIixcbiAgYXBpS2V5OiBcInhhdV9USEZ5SVRUVEVEdUk1eUs4ZDBkQXUxQzV4MUF1ZTNPaDFcIiwgLy8gUmVwbGFjZSB3aXRoIHlvdXIgYWN0dWFsIEFQSSBrZXlcbn07XG4vKiogQHR5cGVkZWYgeyBpbXBvcnQoJy4vdHlwZXMnKS5EYXRhYmFzZVNjaGVtYSB9IERhdGFiYXNlU2NoZW1hICovXG4vKiogQGV4dGVuZHMgRGF0YWJhc2VDbGllbnQ8RGF0YWJhc2VTY2hlbWE+ICovXG5leHBvcnQgY2xhc3MgWGF0YUNsaWVudCBleHRlbmRzIERhdGFiYXNlQ2xpZW50IHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHN1cGVyKHsgLi4uZGVmYXVsdE9wdGlvbnMsIC4uLm9wdGlvbnMgfSwgdGFibGVzKTtcbiAgfVxufVxubGV0IGluc3RhbmNlID0gdW5kZWZpbmVkO1xuLyoqIEB0eXBlIHsgKCkgPT4gWGF0YUNsaWVudCB9ICovXG5leHBvcnQgY29uc3QgZ2V0WGF0YUNsaWVudCA9ICgpID0+IHtcbiAgaWYgKGluc3RhbmNlKSByZXR1cm4gaW5zdGFuY2U7XG4gIGluc3RhbmNlID0gbmV3IFhhdGFDbGllbnQoKTtcbiAgcmV0dXJuIGluc3RhbmNlO1xufTtcblxuIl0sIm5hbWVzIjpbImJ1aWxkQ2xpZW50IiwidGFibGVzIiwibmFtZSIsImNvbHVtbnMiLCJ0eXBlIiwiRGF0YWJhc2VDbGllbnQiLCJkZWZhdWx0T3B0aW9ucyIsImRhdGFiYXNlVVJMIiwiYXBpS2V5IiwiWGF0YUNsaWVudCIsImNvbnN0cnVjdG9yIiwib3B0aW9ucyIsImluc3RhbmNlIiwidW5kZWZpbmVkIiwiZ2V0WGF0YUNsaWVudCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./src/xata.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/property/update-property.js"));
module.exports = __webpack_exports__;

})();